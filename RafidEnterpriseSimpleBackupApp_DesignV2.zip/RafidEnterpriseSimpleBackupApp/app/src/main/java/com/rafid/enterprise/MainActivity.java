package com.rafid.enterprise;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private final String APP_NAME = "মেসার্স রাফিদ এন্টারপ্রাইজ";
    private final String DATA_KEY = "RAFID_ENTERPRISE_SIMPLE_BACKUP_HISTORY";
    private final int REQ_CREATE_BACKUP = 101;
    private final int REQ_IMPORT_BACKUP = 102;

    private SharedPreferences prefs;
    private JSONArray entries = new JSONArray();
    private LinearLayout root, content;
    private ScrollView scrollView;
    private TextView totalAmountText, totalEntryText;
    private EditText nameInput, subjectInput, amountInput, dateTimeInput;
    private Button saveButton;
    private String editingId = "";

    private final int BG_DARK = Color.rgb(2, 6, 23);
    private final int CARD = Color.rgb(10, 18, 36);
    private final int CARD_2 = Color.rgb(15, 28, 52);
    private final int TEXT = Color.WHITE;
    private final int MUTED = Color.rgb(203, 213, 225);
    private final int BLUE = Color.rgb(56, 189, 248);
    private final int GREEN = Color.rgb(34, 197, 94);
    private final int YELLOW = Color.rgb(250, 204, 21);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("rafid_simple_backup_data", MODE_PRIVATE);
        loadData();
        requestStoragePermissionOnce();
        buildUI();
        render();
    }

    private void requestStoragePermissionOnce() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 32 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 33);
        }
    }

    private void loadData() {
        try { entries = new JSONArray(prefs.getString(DATA_KEY, "[]")); }
        catch(Exception e) { entries = new JSONArray(); }
    }

    private void saveData() {
        prefs.edit().putString(DATA_KEY, entries.toString()).apply();
    }

    private void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.setBackground(makeGradient(new int[]{Color.rgb(1,5,15), Color.rgb(8,17,35), Color.rgb(0,0,0)}));
        setContentView(root);

        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, -1));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(content, new ScrollView.LayoutParams(-1, -2));
    }

    private void render() {
        content.removeAllViews();
        buildHeader();
        buildForm();
        buildHistory();
        buildBackupPanel();
    }

    private void buildHeader() {
        LinearLayout heroOuter = new LinearLayout(this);
        heroOuter.setPadding(dp(2), dp(2), dp(2), dp(2));
        heroOuter.setBackground(makeRoundGradient(new int[]{Color.rgb(56,189,248), Color.rgb(34,197,94), Color.rgb(250,204,21)}, dp(28)));
        LinearLayout.LayoutParams outerLp = new LinearLayout.LayoutParams(-1, -2);
        outerLp.setMargins(0, 0, 0, dp(14));
        content.addView(heroOuter, outerLp);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.setBackground(makeRoundGradient(new int[]{Color.rgb(15,23,42), Color.rgb(30,64,175), Color.rgb(8,47,73)}, dp(26)));
        heroOuter.addView(hero, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(brandRow);

        TextView logo = new TextView(this);
        logo.setText("RE");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(22);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable logoBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{YELLOW, GREEN, BLUE});
        logoBg.setShape(GradientDrawable.OVAL);
        logoBg.setStroke(dp(3), Color.WHITE);
        logo.setBackground(logoBg);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(66), dp(66));
        logoLp.setMargins(0,0,dp(12),0);
        brandRow.addView(logo, logoLp);

        LinearLayout nameBox = new LinearLayout(this);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        brandRow.addView(nameBox, new LinearLayout.LayoutParams(0, -2, 1));

        TextView title = new TextView(this);
        title.setText(APP_NAME);
        title.setTextColor(YELLOW);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        nameBox.addView(title);

        TextView sub = new TextView(this);
        sub.setText("নাম, বিষয়, টাকা, তারিখ ও সময় হিসাব");
        sub.setTextColor(Color.rgb(219,234,254));
        sub.setTextSize(14);
        sub.setTypeface(Typeface.DEFAULT_BOLD);
        sub.setPadding(0, dp(5), 0, 0);
        nameBox.addView(sub);

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.HORIZONTAL);
        summary.setPadding(0, dp(16), 0, 0);
        hero.addView(summary);

        totalAmountText = summaryBox(summary, "মোট টাকা", "৳0", Color.rgb(147,197,253));
        totalEntryText = summaryBox(summary, "মোট হিসাব", "0", Color.rgb(134,239,172));
        updateSummary();
    }

    private void buildForm() {
        LinearLayout panel = premiumCard();
        panel.addView(sectionTitle("নতুন হিসাব লিখুন", "LOCAL SAVE"));

        nameInput = input("নাম", "যেমন: রহিম / করিম / দোকান");
        panel.addView(wrap("নাম", nameInput, 58));

        subjectInput = input("বিষয়", "যেমন: বাজার / গাড়ি ভাড়া / মাল আনা");
        subjectInput.setSingleLine(false);
        subjectInput.setMinLines(3);
        panel.addView(wrap("বিষয়", subjectInput, 98));

        amountInput = input("কত টাকা", "যেমন: 500");
        amountInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        panel.addView(wrap("কত টাকা", amountInput, 58));

        dateTimeInput = input("তারিখ ও সময়", "");
        dateTimeInput.setText(nowDateTime());
        panel.addView(wrap("তারিখ ও সময়", dateTimeInput, 58));

        saveButton = mainButton("💾 হিসাব সেভ করুন");
        saveButton.setTextSize(15);
        saveButton.setOnClickListener(v -> saveEntry());
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, dp(56));
        btnLp.setMargins(0, dp(4), 0, 0);
        panel.addView(saveButton, btnLp);

        content.addView(panel);
    }

    private void buildHistory() {
        LinearLayout panel = premiumCard();
        panel.addView(sectionTitle("সেভ হিস্ট্রি", "EDITABLE"));

        if (entries.length() == 0) {
            panel.addView(empty("এখনো কোনো হিসাব লেখা হয়নি।"));
        } else {
            for (int i = entries.length() - 1; i >= 0; i--) {
                try { panel.addView(entryView(entries.getJSONObject(i))); }
                catch(Exception ignored) {}
            }
        }

        content.addView(panel);
    }

    private View entryView(JSONObject o) {
        LinearLayout boxOuter = new LinearLayout(this);
        boxOuter.setPadding(dp(1), dp(1), dp(1), dp(1));
        boxOuter.setBackground(makeRoundGradient(new int[]{Color.rgb(56,189,248), Color.rgb(34,197,94)}, dp(20)));
        LinearLayout.LayoutParams outerLp = new LinearLayout.LayoutParams(-1, -2);
        outerLp.setMargins(0, 0, 0, dp(12));
        boxOuter.setLayoutParams(outerLp);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(makeSolidRound(Color.rgb(7,13,28), dp(19), 0));
        boxOuter.addView(box, new LinearLayout.LayoutParams(-1, -2));

        TextView name = new TextView(this);
        name.setText("👤 " + o.optString("name"));
        name.setTextColor(Color.WHITE);
        name.setTextSize(19);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setSingleLine(false);
        box.addView(name);

        TextView amount = new TextView(this);
        amount.setText("💰 " + money(o.optDouble("amount")));
        amount.setTextColor(Color.rgb(134,239,172));
        amount.setTextSize(20);
        amount.setTypeface(Typeface.DEFAULT_BOLD);
        amount.setPadding(0, dp(6), 0, 0);
        box.addView(amount);

        TextView subject = new TextView(this);
        subject.setText("📝 বিষয়: " + o.optString("subject"));
        subject.setTextColor(Color.rgb(226,232,240));
        subject.setTextSize(16);
        subject.setLineSpacing(5, 1);
        subject.setSingleLine(false);
        subject.setPadding(0, dp(10), 0, 0);
        box.addView(subject);

        TextView date = new TextView(this);
        date.setText("🕒 তারিখ ও সময়: " + o.optString("dateTime"));
        date.setTextColor(Color.rgb(203,213,225));
        date.setTextSize(15);
        date.setTypeface(Typeface.DEFAULT_BOLD);
        date.setPadding(0, dp(8), 0, dp(12));
        date.setSingleLine(false);
        box.addView(date);

        Button edit = smallButton("✏️ Edit");
        edit.setTextSize(15);
        edit.setOnClickListener(v -> editEntry(o.optString("id")));
        box.addView(edit, new LinearLayout.LayoutParams(-1, dp(50)));

        return boxOuter;
    }

    private void buildBackupPanel() {
        LinearLayout panel = premiumCard();
        panel.addView(sectionTitle("Backup & Restore", "SAFE DATA"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button backup = smallButton("⬇️ Backup Save");
        backup.setTextSize(14);
        backup.setOnClickListener(v -> createBackupFile());

        Button restore = smallButton("⬆️ Import / Restore");
        restore.setTextSize(14);
        restore.setOnClickListener(v -> importBackupFile());

        row.addView(backup, new LinearLayout.LayoutParams(0, dp(54), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1);
        lp.setMargins(dp(8), 0, 0, 0);
        row.addView(restore, lp);

        panel.addView(row);
        content.addView(panel);
    }

    private void saveEntry() {
        String name = nameInput.getText().toString().trim();
        String subject = subjectInput.getText().toString().trim();
        double amount = num(amountInput);
        String dateTime = dateTimeInput.getText().toString().trim();

        if (name.isEmpty()) { toast("নাম লিখুন"); return; }
        if (subject.isEmpty()) { toast("বিষয় লিখুন"); return; }
        if (amount <= 0) { toast("সঠিক টাকা লিখুন"); return; }
        if (dateTime.isEmpty()) { toast("তারিখ ও সময় লিখুন"); return; }

        try {
            JSONObject o = new JSONObject();
            o.put("id", editingId.isEmpty() ? String.valueOf(System.currentTimeMillis()) : editingId);
            o.put("name", name);
            o.put("subject", subject);
            o.put("amount", amount);
            o.put("dateTime", dateTime);
            o.put("createdAt", System.currentTimeMillis());

            if (editingId.isEmpty()) {
                entries.put(o);
                toast("হিসাব সেভ হয়েছে ✅");
            } else {
                for (int i = 0; i < entries.length(); i++) {
                    if (editingId.equals(entries.getJSONObject(i).optString("id"))) {
                        entries.put(i, o);
                        break;
                    }
                }
                toast("হিসাব আপডেট হয়েছে ✅");
            }

            editingId = "";
            saveData();
            clearForm();
            render();
        } catch(Exception e) { toast("Save error"); }
    }

    private void editEntry(String id) {
        try {
            for (int i = 0; i < entries.length(); i++) {
                JSONObject o = entries.getJSONObject(i);
                if (id.equals(o.optString("id"))) {
                    nameInput.setText(o.optString("name"));
                    subjectInput.setText(o.optString("subject"));
                    amountInput.setText(String.valueOf(o.optDouble("amount")));
                    dateTimeInput.setText(o.optString("dateTime"));
                    editingId = id;
                    saveButton.setText("✅ হিসাব আপডেট করুন");
                    scrollToTop();
                    return;
                }
            }
        } catch(Exception ignored) {}
    }

    private void clearForm() {
        nameInput.setText("");
        subjectInput.setText("");
        amountInput.setText("");
        dateTimeInput.setText(nowDateTime());
        if (saveButton != null) saveButton.setText("💾 হিসাব সেভ করুন");
    }

    private void createBackupFile() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "rafid-simple-backup-" + todayDate() + ".json");
        startActivityForResult(i, REQ_CREATE_BACKUP);
    }

    private void importBackupFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        startActivityForResult(i, REQ_IMPORT_BACKUP);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (req == REQ_CREATE_BACKUP) {
            try {
                JSONObject backup = new JSONObject();
                backup.put("app", APP_NAME);
                backup.put("type", "simple-history-backup");
                backup.put("version", "1.1");
                backup.put("createdAt", new Date().toString());
                backup.put("entries", entries);

                OutputStream out = getContentResolver().openOutputStream(uri);
                out.write(backup.toString(2).getBytes("UTF-8"));
                out.close();
                toast("Backup save হয়েছে ✅");
            } catch(Exception e) { toast("Backup save failed"); }
        }

        if (req == REQ_IMPORT_BACKUP) {
            try {
                String txt = readAll(getContentResolver().openInputStream(uri));
                JSONObject backup = new JSONObject(txt);
                if (!backup.has("entries")) { toast("ভুল backup file"); return; }
                entries = backup.getJSONArray("entries");
                saveData();
                editingId = "";
                render();
                toast("Backup restore হয়েছে ✅");
            } catch(Exception e) { toast("Import failed"); }
        }
    }

    private String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private void updateSummary() {
        double total = 0;
        for (int i = 0; i < entries.length(); i++) {
            try { total += entries.getJSONObject(i).optDouble("amount"); }
            catch(Exception ignored) {}
        }
        if (totalAmountText != null) totalAmountText.setText(money(total));
        if (totalEntryText != null) totalEntryText.setText(String.valueOf(entries.length()));
    }

    private void scrollToTop() {
        if (scrollView != null) scrollView.postDelayed(() -> scrollView.smoothScrollTo(0, 0), 120);
    }

    private TextView summaryBox(LinearLayout parent, String label, String value, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(8), dp(12), dp(8), dp(12));
        box.setBackground(makeSolidRound(Color.argb(150,2,6,23), dp(18), Color.argb(45,255,255,255)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4),0,dp(4),0);
        parent.addView(box, lp);

        TextView l = new TextView(this);
        l.setText(label); l.setTextColor(Color.rgb(203,213,225)); l.setTextSize(12);
        l.setTypeface(Typeface.DEFAULT_BOLD); l.setGravity(Gravity.CENTER);
        box.addView(l);

        TextView v = new TextView(this);
        v.setText(value); v.setTextColor(color); v.setTextSize(17);
        v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(3), 0, 0);
        box.addView(v);
        return v;
    }

    private View sectionTitle(String title, String tag) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 0, 0, dp(14));

        TextView t = new TextView(this);
        t.setText(title); t.setTextColor(Color.WHITE); t.setTextSize(21);
        t.setTypeface(Typeface.DEFAULT_BOLD); t.setSingleLine(false);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));

        TextView g = new TextView(this);
        g.setText(tag); g.setTextColor(Color.rgb(15,23,42)); g.setTextSize(11);
        g.setTypeface(Typeface.DEFAULT_BOLD); g.setPadding(dp(10), dp(6), dp(10), dp(6));
        g.setBackground(makeSolidRound(YELLOW, dp(20), 0));
        row.addView(g);
        return row;
    }

    private EditText input(String label, String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(100,116,139));
        e.setTextColor(Color.WHITE);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setPadding(dp(14),0,dp(14),0);
        e.setBackground(makeSolidRound(Color.rgb(3, 8, 22), dp(16), Color.argb(55,255,255,255)));
        return e;
    }

    private View wrap(String label, View child, int height) {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);

        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(Color.rgb(226,232,240));
        l.setTextSize(15);
        l.setTypeface(Typeface.DEFAULT_BOLD);
        l.setPadding(0,0,0,dp(7));
        w.addView(l);

        w.addView(child, new LinearLayout.LayoutParams(-1, dp(height)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0,0,0,dp(12));
        w.setLayoutParams(lp);
        return w;
    }

    private Button mainButton(String s) {
        Button b = smallButton(s);
        b.setBackground(makeRoundGradient(new int[]{Color.rgb(56,189,248), Color.rgb(37,99,235), Color.rgb(34,197,94)}, dp(18)));
        return b;
    }

    private Button smallButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(s); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setTextColor(Color.WHITE);
        b.setBackground(makeSolidRound(Color.rgb(31, 41, 59), dp(16), Color.argb(55,255,255,255)));
        return b;
    }

    private TextView empty(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.rgb(148,163,184));
        t.setGravity(Gravity.CENTER); t.setTextSize(15);
        t.setPadding(dp(20), dp(20), dp(20), dp(20));
        return t;
    }

    private LinearLayout premiumCard() {
        LinearLayout outer = new LinearLayout(this);
        outer.setPadding(dp(1), dp(1), dp(1), dp(1));
        outer.setBackground(makeRoundGradient(new int[]{Color.rgb(56,189,248), Color.rgb(30,64,175)}, dp(24)));
        LinearLayout.LayoutParams outerLp = new LinearLayout.LayoutParams(-1, -2);
        outerLp.setMargins(0,0,0,dp(15));
        outer.setLayoutParams(outerLp);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(15), dp(15), dp(15), dp(15));
        inner.setBackground(makeSolidRound(CARD, dp(23), 0));
        outer.addView(inner, new LinearLayout.LayoutParams(-1, -2));

        content.addView(outer);
        return inner;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackground(makeSolidRound(CARD, dp(22), Color.argb(35,255,255,255)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0,0,0,dp(14));
        l.setLayoutParams(lp);
        return l;
    }

    private double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString()); }
        catch(Exception x) { return 0; }
    }

    private String money(double n) { return "৳" + String.format(Locale.US, "%,.0f", n); }
    private String todayDate() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String nowDateTime() { return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private Drawable makeSolidRound(int color, int rad, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(rad);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Drawable makeRoundGradient(int[] colors, int rad) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        g.setCornerRadius(rad);
        return g;
    }

    private Drawable makeGradient(int[] colors) {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
    }
}
