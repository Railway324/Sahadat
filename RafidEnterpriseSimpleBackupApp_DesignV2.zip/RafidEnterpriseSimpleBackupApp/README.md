# Rafid Enterprise Simple Backup App Design V2

Updated design and larger history text.
